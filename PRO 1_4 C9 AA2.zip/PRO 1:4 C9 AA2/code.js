var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["3e58d8db-6e2c-43aa-b7d2-96c0257e3c57","568b141c-3caa-49c9-90ca-6e33b19b7e2c","ae4ef600-825a-425f-9925-b6da742e2179","69748377-6573-496f-99e7-79886b5a3744","75c2cdc5-a498-4a1b-941e-c8270558c5a5","44d74832-fdf7-4cf3-8759-e91811fde027"],"propsByKey":{"3e58d8db-6e2c-43aa-b7d2-96c0257e3c57":{"name":"blue_shirt_hand_up3_1","sourceUrl":null,"frameSize":{"x":13,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"kLFN6EsmqdPAWlXmIK37T.87i80E_LUh","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":13,"y":30},"rootRelativePath":"assets/3e58d8db-6e2c-43aa-b7d2-96c0257e3c57.png"},"568b141c-3caa-49c9-90ca-6e33b19b7e2c":{"name":"car_black_1","sourceUrl":null,"frameSize":{"x":20,"y":37},"frameCount":1,"looping":true,"frameDelay":12,"version":"s6SqR6f9UNDSdp0iyhR__4VQkGQQA6Cs","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":37},"rootRelativePath":"assets/568b141c-3caa-49c9-90ca-6e33b19b7e2c.png"},"ae4ef600-825a-425f-9925-b6da742e2179":{"name":"car_green_1","sourceUrl":null,"frameSize":{"x":17,"y":31},"frameCount":1,"looping":true,"frameDelay":12,"version":"6wh2hTnuOEME13QT1uECIUO8uHh7mtuE","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":17,"y":31},"rootRelativePath":"assets/ae4ef600-825a-425f-9925-b6da742e2179.png"},"69748377-6573-496f-99e7-79886b5a3744":{"name":"car_yellow_1","sourceUrl":null,"frameSize":{"x":17,"y":31},"frameCount":1,"looping":true,"frameDelay":12,"version":"NO60neIJ4GFPz3KrlcED4kgmhNPGBnXV","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":17,"y":31},"rootRelativePath":"assets/69748377-6573-496f-99e7-79886b5a3744.png"},"75c2cdc5-a498-4a1b-941e-c8270558c5a5":{"name":"car_blue_1","sourceUrl":null,"frameSize":{"x":20,"y":37},"frameCount":1,"looping":true,"frameDelay":12,"version":"a1WEkisSLO9gUEBj5_vYKgEoe7Zdoaa0","categories":["vehicles"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":37},"rootRelativePath":"assets/75c2cdc5-a498-4a1b-941e-c8270558c5a5.png"},"44d74832-fdf7-4cf3-8759-e91811fde027":{"name":"commercial_07_1","sourceUrl":null,"frameSize":{"x":50,"y":34},"frameCount":1,"looping":true,"frameDelay":12,"version":"Bk4Pr6sqB._pa4rk6OklG1l24LEWU73M","categories":["buildings"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":50,"y":34},"rootRelativePath":"assets/44d74832-fdf7-4cf3-8759-e91811fde027.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


var parede1= createSprite(190,120,420,3);
parede1.shapeColor='white';
  
var parede2= createSprite(190,260,420,3);
parede2.shapeColor='white';

var Robinson= createSprite(20,190,13,13);
Robinson.setAnimation("blue_shirt_hand_up3_1");

var carro1= createSprite(100,130,10,10);
carro1.setAnimation("car_black_1");

var carro2= createSprite(215,130,10,10);
carro2.setAnimation("car_green_1");

var carro3= createSprite(165,240,10,10);
carro3.setAnimation("car_yellow_1");

var carro4= createSprite(270,240,10,10);
carro4.setAnimation("car_blue_1");

var otica= createSprite(350,190,40,50);
otica.setAnimation("commercial_07_1");

var gameState = "play";


carro1.velocityY= 3;
carro2.velocityY= 3;
carro3.velocityY= -3;
carro4.velocityY= -3;

function draw() {
  background("black");

  carro1.bounceOff(parede1);
  carro1.bounceOff(parede2);
  carro2.bounceOff(parede1);
  carro2.bounceOff(parede2);
  carro3.bounceOff(parede1);
  carro3.bounceOff(parede2);
  carro4.bounceOff(parede1);
  carro4.bounceOff(parede2);


  if (gameState == "play") {
    if (keyDown(LEFT_ARROW)) {
      Robinson.x= Robinson.x-2 ;  
    }
   
    if (keyDown(RIGHT_ARROW)) {
      Robinson.x= Robinson.x+3 ;       
    }
  
    if (Robinson.isTouching(carro1)||Robinson.isTouching(carro2)||Robinson.isTouching(carro3)
    ||Robinson.isTouching(carro4)) {
      Robinson.x=20;
      Robinson.y=190;
    }
  
    if (Robinson.isTouching(otica)) {
      gameState = "end";
    }
  }
  if (gameState == "end") {
    Robinson.velocityX =0;
    Robinson.velocityY = 0;
    textSize(15);
    fill("white");
    text("Robinson chegou na otica", 125, 190);
  }
  
  createEdgeSprites();
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
